# react-native-websocket-server-demo

1 - Run `npm i` to install dependencies

2 - Run the app via `react-native run-ios`


